# AEB baseline comparison

Development pilot. Outputs are unedited; references are drafts.

## AEB-TC-001 — Initial output values

Status: generated

### Generated output

### Preconditions  
- Controller is powered on and initialized.  
- All calibrations are at default values:  
  - `AEB_Enable_C = 1`  
  - `AEB_MinSpd_C = 10.0 km/h`  
  - `AEB_MaxSpd_C = 80.0 km/h`  
  - `AEB_TTCActivate_C = 1.5 s`  
  - `AEB_TTCRelease_C = 2.0 s`  
  - `AEB_DecelCmd_C = -3.0 m/s²`  
- All bypass enables are set to `0`:  
  - `VehSpd_BypEn = 0`  
  - `TargetDetected_BypEn = 0`  
  - `TTC_BypEn = 0`  
  - `TTCValid_BypEn = 0`  
- Raw inputs are set to default values:  
  - `VehSpd_Raw = 0 km/h`  
  - `TargetDetected_Raw = 0`  
  - `TTC_Raw = 0.0 s`  
  - `TTCValid_Raw = 0`  
- No effective inputs are selected via bypass.  

### Test Procedure/Test Steps  
1. **Set** all raw inputs and bypass enables as defined in Preconditions.  
2. **Verify** that `AEB_Active` is `0` (inactive) at initialization.  
3. **Verify** that `AEB_DecelReq` is `0.0 m/s²` at initialization.  
4. **Set** `VehSpd_Raw = 5.0 km/h` and hold for 100 ms.  
5. **Verify** that `AEB_Active` remains `0` and `AEB_DecelReq` remains `0.0 m/s²` throughout the 100 ms window.  
6. **Set** `TargetDetected_Raw = 1` and hold for 100 ms.  
7. **Verify** that `AEB_Active` remains `0` and `AEB_DecelReq` remains `0.0 m/s²` throughout the 100 ms window.  
8. **Set** `TTC_Raw = 1.0 s` and `TTCValid_Raw = 1` and hold for 100 ms.  
9. **Verify** that `AEB_Active` remains `0` and `AEB_DecelReq` remains `0.0 m/s²` throughout the 100 ms window.  
10. **Set** `VehSpd_Raw = 20.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 1.4 s`, `TTCValid_Raw = 1`, and hold for 100 ms.  
11. **Verify** that `AEB_Active` remains `0` and `AEB_DecelReq` remains `0.0 m/s²` throughout the 100 ms window.  
12. **Set** `TTC_Raw = 1.6 s` and hold for 100 ms.  
13. **Verify** that `AEB_Active` remains `0` and `AEB_DecelReq` remains `0.0 m/s²` throughout the 100 ms window.  

### Acceptance Criteria  
- At initialization, `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²`.  
- Throughout the entire test duration (up to 100 ms), after any raw input or bypass change, the outputs remain at:  
  - `AEB_Active = 0`  
  - `AEB_DecelReq = 0.0 m/s²`  
- No change in `AEB_Active` or `AEB_DecelReq` occurs during or after any stimulus application, even when eligibility conditions are met, due to the requirement that the controller starts in an inactive state and only activates when eligibility conditions are satisfied and `TTC_Eff ≤ AEB_TTCActivate_C`.  
- The initial output values are observed before any execution cycle begins, satisfying the requirement in **AEB-REQ-001**.  
- No bypass enables are active; all effective inputs are derived from raw inputs, and no bypass overrides are applied.

### Reference draft

#### Preconditions

1. Set the test harness to capture outputs immediately after the controller initialization routine and before the first normal 10 ms execution.
2. Set simulated raw inputs to `VehSpd_Raw = 50.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 3.0 s`, and `TTCValid_Raw = 1`. Set the initial calibration image to the defaults in specification section 5 and all four bypass enables to `0`.

#### Test Procedure/Test Steps

1. Set the controller to its initialized state by invoking the simulated initialization routine once; capture `AEB_Active` and `AEB_DecelReq` before normal cyclic execution.
2. Verify the captured initial outputs before allowing the first normal cycle.

#### Acceptance Criteria

1. Verify at the initialization observation point that `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²`.
2. Verify the observation precedes the first normal evaluation. If that observation is unavailable, record this case as blocked, not passed.

## AEB-TC-002 — Verify enabled bypass selection, ignored raw-source changes, and selected bypass-value updates for all four inputs using parameterized runs.

Status: generated

### Generated output

### Preconditions  
- Controller initialization: `AEB_Active = 0`, `AEB_DecelReq = 0.0 m/s²`  
- All bypass enables: `VehSpd_BypEn = 0`, `TargetDetected_BypEn = 0`, `TTC_BypEn = 0`, `TTCValid_BypEn = 0`  
- Raw inputs: `VehSpd_Raw = 20.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 1.0 s`, `TTCValid_Raw = 1`  
- Calibrations: `AEB_Enable_C = 1`, `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`, `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, `AEB_DecelCmd_C = -3.0 m/s²`  
- All eligibility conditions are satisfied: speed in range, target detected, TTC valid  

### Test Procedure/Test Steps  
1. **Set** `VehSpd_BypEn = 1`, `VehSpd_BypVal = 30.0 km/h`  
   - Verify that `VehSpd_Eff = 30.0 km/h` within 20 ms of the change.  
2. **Set** `TargetDetected_BypEn = 1`, `TargetDetected_BypVal = 0`  
   - Verify that `TargetDetected_Eff = 0` within 20 ms of the change.  
3. **Set** `TTC_BypEn = 1`, `TTC_BypVal = 0.5 s`  
   - Verify that `TTC_Eff = 0.5 s` within 20 ms of the change.  
4. **Set** `TTCValid_BypEn = 1`, `TTCValid_BypVal = 0`  
   - Verify that `TTCValid_Eff = 0` within 20 ms of the change.  

5. **Set** `VehSpd_BypEn = 1`, `VehSpd_BypVal = 40.0 km/h`  
   - Verify that `VehSpd_Eff = 40.0 km/h` within 20 ms of the change.  
6. **Set** `TargetDetected_BypEn = 1`, `TargetDetected_BypVal = 1`  
   - Verify that `TargetDetected_Eff = 1` within 20 ms of the change.  
7. **Set** `TTC_BypEn = 1`, `TTC_BypVal = 1.8 s`  
   - Verify that `TTC_Eff = 1.8 s` within 20 ms of the change.  
8. **Set** `TTCValid_BypEn = 1`, `TTCValid_BypVal = 1`  
   - Verify that `TTCValid_Eff = 1` within 20 ms of the change.  

9. **Set** `VehSpd_BypEn = 1`, `VehSpd_BypVal = 50.0 km/h`  
   - Verify that `VehSpd_Eff = 50.0 km/h` within 20 ms of the change.  
10. **Set** `TargetDetected_BypEn = 1`, `TargetDetected_BypVal = 0`  
    - Verify that `TargetDetected_Eff = 0` within 20 ms of the change.  
11. **Set** `TTC_BypEn = 1`, `TTC_BypVal = 2.5 s`  
    - Verify that `TTC_Eff = 2.5 s` within 20 ms of the change.  
12. **Set** `TTCValid_BypEn = 1`, `TTCValid_BypVal = 0`  
    - Verify that `TTCValid_Eff = 0` within 20 ms of the change.  

13. **Set** `VehSpd_BypEn = 1`, `VehSpd_BypVal = 60.0 km/h`  
    - Verify that `VehSpd_Eff = 60.0 km/h` within 20 ms of the change.  
14. **Set** `TargetDetected_BypEn = 1`, `TargetDetected_BypVal = 1`  
    - Verify that `TargetDetected_Eff = 1` within 20 ms of the change.  
15. **Set** `TTC_BypEn = 1`, `TTC_BypVal = 1.2 s`  
    - Verify that `TTC_Eff = 1.2 s` within 20 ms of the change.  
16. **Set** `TTCValid_BypEn = 1`, `TTCValid_BypVal = 1`  
    - Verify that `TTCValid_Eff = 1` within 20 ms of the change.  

### Acceptance Criteria  
- For each of the four inputs, when a bypass enable is set to `1` and a bypass value is applied:  
  - The effective input value matches the bypass value within 20 ms of the applied change.  
- When a bypass enable is set to `0`, the effective input remains unchanged from the raw input.  
- Changes to unselected sources (bypass enables = 0) do not affect the effective inputs or outputs.  
- The effective inputs update correctly and within 20 ms of any applied bypass enable or bypass value change.  
- The `AEB_Active` and `AEB_DecelReq` outputs remain consistent with eligibility and state logic (i.e., active only when eligibility conditions are met and TTC_Eff ≤ AEB_TTCActivate_C).  
- No bypass value change or enable change causes a change in `AEB_Active` or `AEB_DecelReq` unless it alters eligibility conditions.  
- All changes to effective inputs are reflected in the logged effective inputs and outputs within 20 ms of the applied change.

### Reference draft

#### Preconditions

1. Set the simulated controller execution period to 10 ms and synchronized post-execution logging to 10 ms; log all applied changes and relevant measurements.
2. Set `AEB_Enable_C = 0`; set `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`, `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, and `AEB_DecelCmd_C = -3.0 m/s²`.
3. Set `VehSpd_Raw = 50.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 3.0 s`, and `TTCValid_Raw = 1` through the simulated input source; set all four bypass enables to `0`.
4. Set `VehSpd_BypVal = 50.0 km/h`, `TargetDetected_BypVal = 1`, `TTC_BypVal = 3.0 s`, and `TTCValid_BypVal = 1`; then set `VehSpd_BypEn = 1`, `TargetDetected_BypEn = 1`, `TTC_BypEn = 1`, and `TTCValid_BypEn = 1`.
5. Verify within 20 ms that `VehSpd_Eff = 50.0 km/h`, `TargetDetected_Eff = 1`, `TTC_Eff = 3.0 s`, and `TTCValid_Eff = 1`; verify `AEB_Active = 0` after the disabled setup has been applied for 20 ms.
6. Set `AEB_Enable_C = 0` and hold for 100 ms; verify `AEB_Active = 0` throughout this window because TTC is 3.0 s.
7. Set up each row below as an independent run. The prefix denotes the exact `_Raw`, `_BypEn`, `_BypVal`, and `_Eff` names in the specification. Use the unit listed in the row.

| Input prefix | Unit | Raw A | Bypass B | Raw C | Bypass D |
| --- | --- | --- | --- | --- | --- |
| `VehSpd` | km/h | 40.0 | 50.0 | 60.0 | 70.0 |
| `TargetDetected` | Boolean | 0 | 1 | 0 | 0 |
| `TTC` | s | 3.0 | 1.4 | 2.5 | 1.2 |
| `TTCValid` | Boolean | 0 | 1 | 0 | 0 |

For Boolean rows, Raw C equals Raw A; the ignored-source check below explicitly toggles raw 0 → 1 → 0 instead.

#### Test Procedure/Test Steps

1. Set the selected input’s bypass enable to `0`; set its raw input to Raw A and its bypass value to Bypass B. Verify the effective input equals Raw A within 20 ms.
2. Set the selected bypass enable to `1`; verify the effective input becomes Bypass B within 20 ms and remains at Bypass B for the rest of the 100 ms window.
3. Set the raw input to Raw C for numeric rows. For Boolean rows, set raw to `1` for 100 ms, then `0` for 100 ms. Verify the effective input remains Bypass B throughout every window.
4. Set the selected bypass value to Bypass D; verify the effective input becomes Bypass D within 20 ms and remains there through 100 ms. Repeat from preconditions for each input row.

#### Acceptance Criteria

1. Verify for all four rows that enabling the bypass selects Bypass B within 20 ms.
2. Verify raw-source changes never alter the selected effective value while bypass remains enabled.
3. Verify changing the selected bypass value produces Bypass D within 20 ms; no output-state assertion is required for this selector-focused case.

## AEB-TC-003 — Verify disabled bypass selects raw, ignores bypass-value changes including both Boolean transitions, and follows raw-source changes for all four inputs using parameterized runs.

Status: generated

### Generated output

### Preconditions  
- Controller initialized: `AEB_Active = 0`, `AEB_DecelReq = 0.0 m/s²`  
- All bypass enables set to `0`:  
  - `VehSpd_BypEn = 0`, `TargetDetected_BypEn = 0`, `TTC_BypEn = 0`, `TTCValid_BypEn = 0`  
- Raw inputs set to:  
  - `VehSpd_Raw = 20.0 km/h`  
  - `TargetDetected_Raw = 1`  
  - `TTC_Raw = 1.0 s`  
  - `TTCValid_Raw = 1`  
- Calibration values at default:  
  - `AEB_Enable_C = 1`  
  - `AEB_MinSpd_C = 10.0 km/h`  
  - `AEB_MaxSpd_C = 80.0 km/h`  
  - `AEB_TTCActivate_C = 1.5 s`  
  - `AEB_TTCRelease_C = 2.0 s`  
  - `AEB_DecelCmd_C = -3.0 m/s²`  

### Test Procedure/Test Steps  
1. **Set** all bypass enables to `0` (default disabled bypass).  
2. **Set** raw inputs as defined in Preconditions.  
3. **Verify** that effective inputs equal raw inputs:  
   - `VehSpd_Eff = 20.0 km/h`  
   - `TargetDetected_Eff = 1`  
   - `TTC_Eff = 1.0 s`  
   - `TTCValid_Eff = 1`  
4. **Set** `VehSpd_BypEn = 1` and `VehSpd_BypVal = 30.0 km/h`.  
5. **Verify** that:  
   - `VehSpd_Eff = 30.0 km/h` within 20 ms of the bypass enable change.  
   - `TargetDetected_Eff`, `TTC_Eff`, `TTCValid_Eff` remain unchanged.  
6. **Set** `TargetDetected_BypEn = 1` and `TargetDetected_BypVal = 0`.  
7. **Verify** that:  
   - `TargetDetected_Eff = 0` within 20 ms of the bypass enable change.  
   - `VehSpd_Eff`, `TTC_Eff`, `TTCValid_Eff` remain unchanged.  
8. **Set** `TTC_BypEn = 1` and `TTC_BypVal = 0.5 s`.  
9. **Verify** that:  
   - `TTC_Eff = 0.5 s` within 20 ms of the bypass enable change.  
   - `VehSpd_Eff`, `TargetDetected_Eff`, `TTCValid_Eff` remain unchanged.  
10. **Set** `TTCValid_BypEn = 1` and `TTCValid_BypVal = 0`.  
11. **Verify** that:  
   - `TTCValid_Eff = 0` within 20 ms of the bypass enable change.  
   - All other effective inputs remain unchanged.  
12. **Set** `VehSpd_Raw = 40.0 km/h` (new raw input).  
13. **Verify** that:  
   - `VehSpd_Eff = 40.0 km/h` within 20 ms of the raw input change.  
   - All bypassed inputs remain unchanged.  
14. **Set** `TTC_Raw = 0.8 s` (new raw input).  
15. **Verify** that:  
   - `TTC_Eff = 0.8 s` within 20 ms of the raw input change.  
   - All bypassed inputs remain unchanged.  
16. **Set** `TTC_Raw = 3.0 s` (new raw input).  
17. **Verify** that:  
   - `TTC_Eff = 3.0 s` within 20 ms of the raw input change.  
   - All bypassed inputs remain unchanged.  

### Acceptance Criteria  
- All effective inputs follow raw inputs or bypass values within **20 ms** of any applied change.  
- When a bypass is disabled (`BypEn = 0`), the effective input equals the raw input.  
- When a bypass is enabled (`BypEn = 1`), the effective input equals the bypass value, and **no other effective input changes**.  
- Bypass enable changes (Boolean transitions) do not alter the effective input of other sources unless explicitly set.  
- Raw input changes (e.g., `VehSpd_Raw`, `TTC_Raw`) are reflected in the effective input within 20 ms.  
- Bypass-value changes (e.g., `VehSpd_BypVal`, `TTC_BypVal`) are reflected in the effective input within 20 ms.  
- The effective input for any source **does not change** when a bypass enable is toggled to `1` or `0` unless the source is directly written (raw input or bypass value).  
- All effective inputs remain unchanged during bypass transitions of other inputs.  
- The controller maintains state eligibility (all eligibility conditions true) throughout the test, and no output changes occur due to bypass transitions.

### Reference draft

#### Preconditions

1. Set the simulated controller execution period to 10 ms and synchronized post-execution logging to 10 ms; log all applied changes and relevant measurements.
2. Set `AEB_Enable_C = 0`; set `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`, `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, and `AEB_DecelCmd_C = -3.0 m/s²`.
3. Set `VehSpd_Raw = 50.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 3.0 s`, and `TTCValid_Raw = 1` through the simulated input source; set all four bypass enables to `0`.
4. Set `VehSpd_BypVal = 50.0 km/h`, `TargetDetected_BypVal = 1`, `TTC_BypVal = 3.0 s`, and `TTCValid_BypVal = 1`; then set `VehSpd_BypEn = 1`, `TargetDetected_BypEn = 1`, `TTC_BypEn = 1`, and `TTCValid_BypEn = 1`.
5. Verify within 20 ms that `VehSpd_Eff = 50.0 km/h`, `TargetDetected_Eff = 1`, `TTC_Eff = 3.0 s`, and `TTCValid_Eff = 1`; verify `AEB_Active = 0` after the disabled setup has been applied for 20 ms.
6. Set `AEB_Enable_C = 0` and hold for 100 ms; verify `AEB_Active = 0` throughout this window because TTC is 3.0 s.
7. Set up each row below as an independent run. The prefix denotes the exact `_Raw`, `_BypEn`, `_BypVal`, and `_Eff` names in the specification. Use the unit listed in the row.

| Input prefix | Unit | Raw A | Bypass B | Raw C | Bypass D |
| --- | --- | --- | --- | --- | --- |
| `VehSpd` | km/h | 40.0 | 50.0 | 60.0 | 70.0 |
| `TargetDetected` | Boolean | 0 | 1 | 0 | 0 |
| `TTC` | s | 3.0 | 1.4 | 2.5 | 1.2 |
| `TTCValid` | Boolean | 0 | 1 | 0 | 0 |

For Boolean rows, Raw C equals Raw A. Step 3 toggles the unselected bypass value 0 → 1 → 0 while raw remains 0. Step 4 separately toggles the selected raw value 0 → 1 → 0.

#### Test Procedure/Test Steps

1. Set the selected raw input to Raw A and bypass value to Bypass B; set its bypass enable to `1`. Verify its effective input equals Bypass B within 20 ms.
2. Set the selected bypass enable to `0`; verify the effective input becomes Raw A within 20 ms and remains there through 100 ms.
3. Set the unselected bypass value to Bypass D for numeric rows and hold for 100 ms. For Boolean rows, set the bypass value to `0`, then `1`, then `0`, holding each value for 100 ms while raw remains `0` and bypass enable remains `0`. Verify the effective input remains Raw A at every sample throughout each window.
4. Set raw input to Raw C for numeric rows. For Boolean rows, set raw to `1` for 100 ms, then `0` for 100 ms. Verify each raw change appears at the effective input within 20 ms and persists for the rest of its window. Repeat from preconditions for each input row.

#### Acceptance Criteria

1. Verify for all four rows that disabling the bypass selects Raw A within 20 ms.
2. Verify changes to the unselected bypass value do not alter the effective input.
3. Verify selected raw-source changes appear at the effective input within 20 ms; no output-state assertion is required for this selector-focused case.

## AEB-TC-004 — Activation at the TTC threshold

Status: generated

### Generated output

### Preconditions  
- Controller initialized with default values:  
  - `AEB_Active = 0`  
  - `AEB_DecelReq = 0.0 m/s²`  
- All bypass enables set to `0`:  
  - `VehSpd_BypEn = 0`, `TargetDetected_BypEn = 0`, `TTC_BypEn = 0`, `TTCValid_BypEn = 0`  
- Raw inputs set to:  
  - `VehSpd_Raw = 15.0 km/h`  
  - `TargetDetected_Raw = 1`  
  - `TTC_Raw = 1.4 s`  
  - `TTCValid_Raw = 1`  
- Calibration values at default:  
  - `AEB_Enable_C = 1`  
  - `AEB_MinSpd_C = 10.0 km/h`  
  - `AEB_MaxSpd_C = 80.0 km/h`  
  - `AEB_TTCActivate_C = 1.5 s`  
  - `AEB_TTCRelease_C = 2.0 s`  
  - `AEB_DecelCmd_C = -3.0 m/s²`  

### Test Procedure/Test Steps  
1. **Set** `AEB_Enable_C = 1` (feature enabled).  
2. **Set** `VehSpd_Eff` via bypass: enable `VehSpd_BypEn = 1`, set `VehSpd_BypVal = 15.0 km/h`.  
3. **Set** `TargetDetected_Eff` via bypass: enable `TargetDetected_BypEn = 1`, set `TargetDetected_BypVal = 1`.  
4. **Set** `TTC_Eff` via bypass: enable `TTC_BypEn = 1`, set `TTC_BypVal = 1.4 s`.  
5. **Set** `TTCValid_Eff` via bypass: enable `TTCValid_BypEn = 1`, set `TTCValid_BypVal = 1`.  
6. **Verify** that `AEB_Active = 0` at time t = 0 ms (initial state).  
7. **Verify** that `AEB_DecelReq = 0.0 m/s²` at time t = 0 ms.  
8. Apply raw input change: set `TTC_Raw = 1.4 s` (already active via bypass, no change).  
9. **Verify** that all eligibility conditions are satisfied:  
   - `AEB_Enable_C = 1`  
   - `10.0 ≤ 15.0 ≤ 80.0` (speed within range)  
   - `TargetDetected_Eff = 1`  
   - `TTCValid_Eff = 1`  
10. **Verify** that `TTC_Eff = 1.4 s` and `TTC_Eff ≤ AEB_TTCActivate_C` (1.4 ≤ 1.5).  
11. **Verify** that `AEB_Active` transitions to `1` within 20 ms of the input change.  
12. **Verify** that `AEB_DecelReq` transitions to `-3.0 m/s²` within 20 ms of the input change.  
13. **Verify** that both `AEB_Active` and `AEB_DecelReq` update together (both change simultaneously).  
14. **Verify** that the transition occurs within 20 ms of the applied input change (i.e., from t = 0 to t = 20 ms).  
15. Hold stimulus for 100 ms and **verify** that:  
   - `AEB_Active = 1`  
   - `AEB_DecelReq = -3.0 m/s²`  
   - No changes to `AEB_Active` or `AEB_DecelReq` occur during the 100 ms window unless eligibility changes.  

### Acceptance Criteria  
- `AEB_Active` transitions from `0` to `1` within 20 ms of the condition satisfaction (i.e., eligibility met and `TTC_Eff ≤ 1.5 s`).  
- `AEB_DecelReq` transitions from `0.0 m/s²` to `-3.0 m/s²` within 20 ms of the activation event.  
- Both `AEB_Active` and `AEB_DecelReq` update together and remain active throughout the 100 ms observation window.  
- The activation occurs only when all eligibility conditions are satisfied and `TTC_Eff ≤ AEB_TTCActivate_C`.  
- No activation occurs if any eligibility condition is false or `TTC_Eff > 1.5 s`.  
- The transition is not delayed beyond 20 ms from the applied input change (i.e., from the moment `TTC_Eff` is set to 1.4 s).  
- All effective inputs are derived from bypassed values as per INCA-style interface rules.  
- The output update occurs within the 20 ms maximum response time as defined in the execution conventions.

### Reference draft

#### Preconditions

1. Set the simulated controller execution period to 10 ms and synchronized post-execution logging to 10 ms; log all applied changes and relevant measurements.
2. Set `AEB_Enable_C = 0`; set `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`, `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, and `AEB_DecelCmd_C = -3.0 m/s²`.
3. Set `VehSpd_Raw = 50.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 3.0 s`, and `TTCValid_Raw = 1` through the simulated input source; set all four bypass enables to `0`.
4. Set `VehSpd_BypVal = 50.0 km/h`, `TargetDetected_BypVal = 1`, `TTC_BypVal = 3.0 s`, and `TTCValid_BypVal = 1`; then set `VehSpd_BypEn = 1`, `TargetDetected_BypEn = 1`, `TTC_BypEn = 1`, and `TTCValid_BypEn = 1`.
5. Verify within 20 ms that `VehSpd_Eff = 50.0 km/h`, `TargetDetected_Eff = 1`, `TTC_Eff = 3.0 s`, and `TTCValid_Eff = 1`; verify `AEB_Active = 0` after the disabled setup has been applied for 20 ms.
6. Set `AEB_Enable_C = 1` and hold for 100 ms; verify `AEB_Active = 0` throughout this window because TTC is 3.0 s.

#### Test Procedure/Test Steps

1. Set `TTC_BypVal = 1.6 s`; verify `TTC_Eff = 1.6 s` within 20 ms and verify `AEB_Active = 0` throughout 100 ms.
2. Set `TTC_BypVal = 1.5 s`; verify `TTC_Eff = 1.5 s` and `AEB_Active = 1` within 20 ms of this applied change; hold for 100 ms.

#### Acceptance Criteria

1. Verify AEB remains inactive at 1.6 s when initially inactive.
2. Verify AEB activates at exactly 1.5 s within 20 ms and remains active through the observation window.

## AEB-TC-005 — Activation at the minimum eligible speed

Status: generated

### Generated output

### Preconditions  
- Controller initialization: `AEB_Active = 0`, `AEB_DecelReq = 0.0 m/s²`  
- `AEB_Enable_C = 1` (feature enabled)  
- `AEB_MinSpd_C = 10.0 km/h`  
- `AEB_MaxSpd_C = 80.0 km/h`  
- `AEB_TTCActivate_C = 1.5 s`  
- `AEB_TTCRelease_C = 2.0 s`  
- `AEB_DecelCmd_C = -3.0 m/s²`  
- `VehSpd_Raw = 10.0 km/h` → `VehSpd_Eff = 10.0 km/h` (bypass disabled)  
- `TargetDetected_Raw = 1` → `TargetDetected_Eff = 1` (bypass disabled)  
- `TTC_Raw = 1.5 s` → `TTC_Eff = 1.5 s` (bypass disabled)  
- `TTCValid_Raw = 1` → `TTCValid_Eff = 1` (bypass disabled)  
- All bypass enables: `VehSpd_BypEn = 0`, `TargetDetected_BypEn = 0`, `TTC_BypEn = 0`, `TTCValid_BypEn = 0`  

### Test Procedure/Test Steps  
1. **Set** `AEB_Enable_C = 1` (ensure feature is enabled).  
2. **Set** `VehSpd_Eff = 10.0 km/h` (minimum eligible speed).  
3. **Set** `TargetDetected_Eff = 1` (target detected).  
4. **Set** `TTC_Eff = 1.5 s` (exactly at activation threshold).  
5. **Set** `TTCValid_Eff = 1` (TTC is valid).  
6. **Verify** that `AEB_Active = 0` (controller is inactive initially).  
7. **Verify** that `AEB_DecelReq = 0.0 m/s²` (no deceleration request).  
8. **Apply** the raw input changes at time `t = 0 ms`:  
   - `VehSpd_Raw = 10.0 km/h` (already set, no change)  
   - `TargetDetected_Raw = 1` (already set, no change)  
   - `TTC_Raw = 1.5 s` (already set, no change)  
   - `TTCValid_Raw = 1` (already set, no change)  
9. **Wait** for next controller execution at `t = 10 ms`.  
10. **Verify** that `AEB_Active = 1` within **20 ms** of the input application (i.e., by `t = 20 ms`).  
11. **Verify** that `AEB_DecelReq = -3.0 m/s²` within **20 ms** of input application.  
12. **Verify** that the transition occurs **within 20 ms** of the input change.  
13. **Hold** all inputs and calibrations constant for 100 ms.  
14. **Verify** that `AEB_Active = 1` and `AEB_DecelReq = -3.0 m/s²` at every 10 ms sample from `t = 20 ms` to `t = 120 ms`.  

### Acceptance Criteria  
- `AEB_Active` transitions from `0` to `1` within **20 ms** of the input change.  
- `AEB_DecelReq` transitions from `0.0 m/s²` to `-3.0 m/s²` within **20 ms** of the input change.  
- The activation occurs **only** when all eligibility conditions are satisfied and `TTC_Eff ≤ AEB_TTCActivate_C` (i.e., 1.5 s ≤ 1.5 s).  
- The controller remains active and requests deceleration at `-3.0 m/s²` for the entire 100 ms observation period after activation.  
- No premature activation occurs when `TTC_Eff > 1.5 s` or when any eligibility condition is false.  
- The response time from input change to output update is **≤ 20 ms**.  
- The effective inputs are derived from raw inputs without bypass override.

### Reference draft

#### Preconditions

1. Set the simulated controller execution period to 10 ms and synchronized post-execution logging to 10 ms; log all applied changes and relevant measurements.
2. Set `AEB_Enable_C = 0`; set `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`, `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, and `AEB_DecelCmd_C = -3.0 m/s²`.
3. Set `VehSpd_Raw = 50.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 3.0 s`, and `TTCValid_Raw = 1` through the simulated input source; set all four bypass enables to `0`.
4. Set `VehSpd_BypVal = 10.0 km/h`, `TargetDetected_BypVal = 1`, `TTC_BypVal = 3.0 s`, and `TTCValid_BypVal = 1`; then set `VehSpd_BypEn = 1`, `TargetDetected_BypEn = 1`, `TTC_BypEn = 1`, and `TTCValid_BypEn = 1`.
5. Verify within 20 ms that `VehSpd_Eff = 10.0 km/h`, `TargetDetected_Eff = 1`, `TTC_Eff = 3.0 s`, and `TTCValid_Eff = 1`; verify `AEB_Active = 0` after the disabled setup has been applied for 20 ms.
6. Set `AEB_Enable_C = 1` and hold for 100 ms; verify `AEB_Active = 0` throughout this window because TTC is 3.0 s.

#### Test Procedure/Test Steps

1. Set `TTC_BypVal = 1.4 s`; verify `TTC_Eff = 1.4 s` within 20 ms; hold for 100 ms.
2. Verify from the recorded trace that `VehSpd_Eff = 10.0 km/h` throughout, the first `AEB_Active = 1` sample occurs no later than 20 ms after the applied TTC change, and `AEB_Active = 1` persists through the 100 ms observation window.

#### Acceptance Criteria

1. Verify the inclusive minimum speed of 10.0 km/h permits activation when the other activation conditions are satisfied.
2. Verify activation occurs within 20 ms and persists through 100 ms.

## AEB-TC-006 — Activation at the maximum eligible speed

Status: generated

### Generated output

### Preconditions  
- Controller initialization: `AEB_Active = 0`, `AEB_DecelReq = 0.0 m/s²`  
- All bypass enables set to `0`: `VehSpd_BypEn = 0`, `TargetDetected_BypEn = 0`, `TTC_BypEn = 0`, `TTCValid_BypEn = 0`  
- Raw inputs set to:  
  - `VehSpd_Raw = 80.0 km/h`  
  - `TargetDetected_Raw = 1`  
  - `TTC_Raw = 1.5 s`  
  - `TTCValid_Raw = 1`  
- Calibration values at default:  
  - `AEB_Enable_C = 1`  
  - `AEB_MinSpd_C = 10.0 km/h`  
  - `AEB_MaxSpd_C = 80.0 km/h`  
  - `AEB_TTCActivate_C = 1.5 s`  
  - `AEB_TTCRelease_C = 2.0 s`  
  - `AEB_DecelCmd_C = -3.0 m/s²`  

### Test Procedure/Test Steps  
1. **Set** `VehSpd_Raw = 80.0 km/h` (within maximum eligible speed)  
2. **Set** `TargetDetected_Raw = 1`  
3. **Set** `TTC_Raw = 1.5 s`  
4. **Set** `TTCValid_Raw = 1`  
5. **Set** `TTC_BypEn = 1` and `TTC_BypVal = 1.5 s` to bypass TTC input  
6. **Set** `AEB_Enable_C = 1` (feature enabled)  
7. Execute controller cycle and observe outputs at each 10 ms interval for 100 ms  
8. **Verify** that `AEB_Active = 0` at t = 0 ms (initial state)  
9. **Verify** that `AEB_DecelReq = 0.0 m/s²` at t = 0 ms  
10. **Verify** that `TTC_Eff = 1.5 s` (bypassed value) and `TTCValid_Eff = 1` throughout the 100 ms window  
11. **Verify** that all eligibility conditions are satisfied:  
    - `AEB_Enable_C = 1`  
    - `VehSpd_Eff = 80.0 km/h` (within [10.0, 80.0] km/h)  
    - `TargetDetected_Eff = 1`  
    - `TTCValid_Eff = 1`  
12. **Verify** that `AEB_Active` transitions to `1` within 20 ms of the applied input change (specifically, at t = 10 ms or earlier)  
13. **Verify** that `AEB_DecelReq` transitions to `-3.0 m/s²` within 20 ms of activation  
14. **Verify** that `AEB_Active = 1` and `AEB_DecelReq = -3.0 m/s²` are maintained throughout the 100 ms window (as long as eligibility conditions remain true)  
15. **Verify** that the transition from inactive to active occurs within 20 ms of the input change, and that the deceleration request is updated in parallel with the active state  

### Acceptance Criteria  
- `AEB_Active` transitions from `0` to `1` within 20 ms of the input change (specifically, at or before t = 10 ms)  
- `AEB_DecelReq` transitions from `0.0 m/s²` to `-3.0 m/s²` within 20 ms of activation  
- All eligibility conditions are satisfied at the time of activation  
- The activation occurs only when `TTC_Eff ≤ AEB_TTCActivate_C` (i.e., 1.5 s ≤ 1.5 s)  
- The controller remains active and requests deceleration at `-3.0 m/s²` as long as all eligibility conditions remain true and `TTC_Eff < 2.0 s`  
- No premature activation occurs when `TTC_Eff > 1.5 s` or when any eligibility condition is false  
- Output updates occur within 20 ms of any applied input or calibration change, as per execution timing convention  
- The effective inputs are correctly selected via bypass logic: `TTC_Eff = 1.5 s` due to bypass override  
- The controller does not activate when `TTC_Eff > 1.5 s`, even if vehicle speed and target detection are valid  
- The deceleration request is only set when `AEB_Active = 1` and matches `AEB_DecelCmd_C` as defined in requirement AEB-REQ-007

### Reference draft

#### Preconditions

1. Set the simulated controller execution period to 10 ms and synchronized post-execution logging to 10 ms; log all applied changes and relevant measurements.
2. Set `AEB_Enable_C = 0`; set `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`, `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, and `AEB_DecelCmd_C = -3.0 m/s²`.
3. Set `VehSpd_Raw = 50.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 3.0 s`, and `TTCValid_Raw = 1` through the simulated input source; set all four bypass enables to `0`.
4. Set `VehSpd_BypVal = 80.0 km/h`, `TargetDetected_BypVal = 1`, `TTC_BypVal = 3.0 s`, and `TTCValid_BypVal = 1`; then set `VehSpd_BypEn = 1`, `TargetDetected_BypEn = 1`, `TTC_BypEn = 1`, and `TTCValid_BypEn = 1`.
5. Verify within 20 ms that `VehSpd_Eff = 80.0 km/h`, `TargetDetected_Eff = 1`, `TTC_Eff = 3.0 s`, and `TTCValid_Eff = 1`; verify `AEB_Active = 0` after the disabled setup has been applied for 20 ms.
6. Set `AEB_Enable_C = 1` and hold for 100 ms; verify `AEB_Active = 0` throughout this window because TTC is 3.0 s.

#### Test Procedure/Test Steps

1. Set `TTC_BypVal = 1.4 s`; verify `TTC_Eff = 1.4 s` within 20 ms; hold for 100 ms.
2. Verify from the recorded trace that `VehSpd_Eff = 80.0 km/h` throughout, the first `AEB_Active = 1` sample occurs no later than 20 ms after the applied TTC change, and `AEB_Active = 1` persists through the 100 ms observation window.

#### Acceptance Criteria

1. Verify the inclusive maximum speed of 80.0 km/h permits activation when the other activation conditions are satisfied.
2. Verify activation occurs within 20 ms and persists through 100 ms.

## AEB-TC-007 — Feature-disabled inhibition

Status: generated

### Generated output

### Preconditions  
- Controller initialized with `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²` (per AEB-REQ-001).  
- All bypass enables set to `0`: `VehSpd_BypEn = 0`, `TargetDetected_BypEn = 0`, `TTC_BypEn = 0`, `TTCValid_BypEn = 0`.  
- Raw inputs set to default values: `VehSpd_Raw = 10.0 km/h`, `TargetDetected_Raw = 0`, `TTC_Raw = 3.0 s`, `TTCValid_Raw = 1`.  
- Calibration values at default:  
  - `AEB_Enable_C = 1`  
  - `AEB_MinSpd_C = 10.0 km/h`  
  - `AEB_MaxSpd_C = 80.0 km/h`  
  - `AEB_TTCActivate_C = 1.5 s`  
  - `AEB_TTCRelease_C = 2.0 s`  
  - `AEB_DecelCmd_C = -3.0 m/s²`  

### Test Procedure/Test Steps  
1. **Set** `AEB_Enable_C = 1` (feature enabled).  
2. **Set** `VehSpd_Eff` via raw input to `10.0 km/h` (within eligible speed range).  
3. **Set** `TargetDetected_Eff` via raw input to `0` (target not detected).  
4. **Set** `TTC_Eff` via raw input to `3.0 s` (greater than `AEB_TTCActivate_C`).  
5. **Set** `TTCValid_Eff` via raw input to `1` (valid TTC).  
6. **Verify** that `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²` after 10 ms execution.  
7. **Verify** that `AEB_Active` remains `0` and `AEB_DecelReq` remains `0.0 m/s²` throughout the next 100 ms execution cycle.  
8. **Set** `TargetDetected_Eff = 1` (target detected) and hold for 100 ms.  
9. **Verify** that `AEB_Active` remains `0` and `AEB_DecelReq` remains `0.0 m/s²` throughout the 100 ms period.  
10. **Set** `TTC_Eff = 1.0 s` (less than or equal to `AEB_TTCActivate_C`).  
11. **Verify** that `AEB_Active` remains `0` and `AEB_DecelReq` remains `0.0 m/s²` throughout the 100 ms period.  
12. **Set** `TTC_Eff = 0.5 s` (less than `AEB_TTCActivate_C`).  
13. **Verify** that `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²` after 10 ms execution.  
14. **Verify** that `AEB_Active` remains `0` and `AEB_DecelReq` remains `0.0 m/s²` throughout the next 100 ms execution cycle.  

### Acceptance Criteria  
- When any eligibility condition is false (e.g., `TargetDetected_Eff = 0`), the controller must remain inactive: `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²`.  
- When all eligibility conditions are satisfied and `TTC_Eff > AEB_TTCActivate_C`, the controller must remain inactive: `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²`.  
- The controller must not activate or request deceleration under any of the above false eligibility conditions or when `TTC_Eff > AEB_TTCActivate_C`.  
- All outputs (`AEB_Active`, `AEB_DecelReq`) must remain at `0` and `0.0 m/s²` throughout the 100 ms observation window in all test steps.  
- The response time from input change to output update is within 20 ms, as per requirement AEB-REQ-002.  
- No direct writing or setting of `AEB_Active` or `AEB_DecelReq` is performed; all state transitions are derived from eligibility and TTC conditions.

### Reference draft

#### Preconditions

1. Set the simulated controller execution period to 10 ms and synchronized post-execution logging to 10 ms; log all applied changes and relevant measurements.
2. Set `AEB_Enable_C = 0`; set `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`, `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, and `AEB_DecelCmd_C = -3.0 m/s²`.
3. Set `VehSpd_Raw = 50.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 3.0 s`, and `TTCValid_Raw = 1` through the simulated input source; set all four bypass enables to `0`.
4. Set `VehSpd_BypVal = 50.0 km/h`, `TargetDetected_BypVal = 1`, `TTC_BypVal = 3.0 s`, and `TTCValid_BypVal = 1`; then set `VehSpd_BypEn = 1`, `TargetDetected_BypEn = 1`, `TTC_BypEn = 1`, and `TTCValid_BypEn = 1`.
5. Verify within 20 ms that `VehSpd_Eff = 50.0 km/h`, `TargetDetected_Eff = 1`, `TTC_Eff = 3.0 s`, and `TTCValid_Eff = 1`; verify `AEB_Active = 0` after the disabled setup has been applied for 20 ms.
6. Set `AEB_Enable_C = 0` and hold for 100 ms; verify `AEB_Active = 0` throughout this window because TTC is 3.0 s.

#### Test Procedure/Test Steps

1. Set `TTC_BypVal = 1.4 s`; verify `TTC_Eff = 1.4 s` within 20 ms; hold for 100 ms.
2. Verify `AEB_Enable_C = 0` persists and verify `AEB_Active = 0` at every sample throughout the window.

#### Acceptance Criteria

1. Verify AEB remains inactive for the full 100 ms with `AEB_Enable_C = 0`, despite TTC being below the activation threshold.

## AEB-TC-008 — Missing-target inhibition

Status: generated

### Generated output

### Preconditions  
- Controller initialization: `AEB_Active = 0`, `AEB_DecelReq = 0.0 m/s²`  
- `AEB_Enable_C = 1` (feature enabled)  
- `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`  
- `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, `AEB_DecelCmd_C = -3.0 m/s²`  
- `VehSpd_Raw = 20.0 km/h` → `VehSpd_Eff = 20.0 km/h` (bypass disabled)  
- `TargetDetected_Raw = 1` → `TargetDetected_Eff = 1` (bypass disabled)  
- `TTC_Raw = 3.0 s` → `TTC_Eff = 3.0 s` (bypass disabled)  
- `TTCValid_Raw = 1` → `TTCValid_Eff = 1` (bypass disabled)  
- All bypass enables: `VehSpd_BypEn = 0`, `TargetDetected_BypEn = 0`, `TTC_BypEn = 0`, `TTCValid_BypEn = 0`  

### Test Procedure/Test Steps  
1. **Set** `TTC_Eff = 3.0 s` (via `TTC_Raw = 3.0 s`, bypass disabled)  
2. **Set** `TTCValid_Eff = 1` (via `TTCValid_Raw = 1`, bypass disabled)  
3. **Verify** that `AEB_Active = 0` (controller remains inactive)  
4. **Set** `TTC_Eff = 1.2 s` (via `TTC_Raw = 1.2 s`, bypass disabled)  
5. **Verify** that `AEB_Active = 0` (controller remains inactive)  
6. **Set** `TTC_Eff = 1.4 s` (via `TTC_Raw = 1.4 s`, bypass disabled)  
7. **Verify** that `AEB_Active = 0` (controller remains inactive)  
8. **Set** `TTC_Eff = 1.5 s` (via `TTC_Raw = 1.5 s`, bypass disabled)  
9. **Verify** that `AEB_Active = 0` (controller remains inactive)  
10. **Set** `TTC_Eff = 1.6 s` (via `TTC_Raw = 1.6 s`, bypass disabled)  
11. **Verify** that `AEB_Active = 0` (controller remains inactive)  

### Acceptance Criteria  
- When `TTC_Eff > AEB_TTCActivate_C` (i.e., TTC > 1.5 s), `AEB_Active` must remain `0` and `AEB_DecelReq` must remain `0.0 m/s²`  
- When `TTC_Eff ≤ AEB_TTCActivate_C` (i.e., TTC ≤ 1.5 s), the controller **does not activate** due to the falsity of eligibility conditions (specifically, `TTCValid_Eff = 0` or any other eligibility condition being false)  
- All validation points must occur within 20 ms of the applied input change  
- The controller must **not** transition to active state when any eligibility condition is false or when `TTC_Eff > AEB_TTCActivate_C`  
- Output values `AEB_Active` and `AEB_DecelReq` must remain unchanged and equal to `0` throughout the test period, regardless of the TTC value, as long as any eligibility condition is false or TTC > 1.5 s  
- No bypass override is applied; all effective inputs are derived from raw inputs with bypass enables set to `0`  
- All observations are logged every 10 ms, with timestamps aligned to applied changes for timing verification

### Reference draft

#### Preconditions

1. Set the simulated controller execution period to 10 ms and synchronized post-execution logging to 10 ms; log all applied changes and relevant measurements.
2. Set `AEB_Enable_C = 0`; set `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`, `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, and `AEB_DecelCmd_C = -3.0 m/s²`.
3. Set `VehSpd_Raw = 50.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 3.0 s`, and `TTCValid_Raw = 1` through the simulated input source; set all four bypass enables to `0`.
4. Set `VehSpd_BypVal = 50.0 km/h`, `TargetDetected_BypVal = 0`, `TTC_BypVal = 3.0 s`, and `TTCValid_BypVal = 1`; then set `VehSpd_BypEn = 1`, `TargetDetected_BypEn = 1`, `TTC_BypEn = 1`, and `TTCValid_BypEn = 1`.
5. Verify within 20 ms that `VehSpd_Eff = 50.0 km/h`, `TargetDetected_Eff = 0`, `TTC_Eff = 3.0 s`, and `TTCValid_Eff = 1`; verify `AEB_Active = 0` after the disabled setup has been applied for 20 ms.
6. Set `AEB_Enable_C = 1` and hold for 100 ms; verify `AEB_Active = 0` throughout this window because TTC is 3.0 s.

#### Test Procedure/Test Steps

1. Set `TTC_BypVal = 1.4 s`; verify `TTC_Eff = 1.4 s` within 20 ms; hold for 100 ms.
2. Verify `TargetDetected_Eff = 0` persists and verify `AEB_Active = 0` at every sample throughout the window.

#### Acceptance Criteria

1. Verify AEB remains inactive for the full 100 ms with `TargetDetected_Eff = 0`, despite TTC being below the activation threshold.

## AEB-TC-009 — Invalid-TTC inhibition

Status: generated

### Generated output

### Preconditions  
- Controller initialization: `AEB_Active = 0`, `AEB_DecelReq = 0.0 m/s²`  
- All bypass enables set to `0`: `VehSpd_BypEn = 0`, `TargetDetected_BypEn = 0`, `TTC_BypEn = 0`, `TTCValid_BypEn = 0`  
- Raw inputs set to:  
  - `VehSpd_Raw = 15.0 km/h`  
  - `TargetDetected_Raw = 1`  
  - `TTC_Raw = 2.5 s`  
  - `TTCValid_Raw = 1`  
- Calibration values at default:  
  - `AEB_Enable_C = 1`  
  - `AEB_MinSpd_C = 10.0 km/h`  
  - `AEB_MaxSpd_C = 80.0 km/h`  
  - `AEB_TTCActivate_C = 1.5 s`  
  - `AEB_TTCRelease_C = 2.0 s`  
  - `AEB_DecelCmd_C = -3.0 m/s²`  

### Test Procedure/Test Steps  
1. **Set** `TTC_Raw = 3.0 s` (to exceed activation threshold)  
2. **Verify** that `TTC_Eff = 3.0 s` (via bypass disable, raw input unchanged)  
3. **Verify** that `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²` throughout the 100 ms observation window  
4. **Set** `TTC_Raw = 0.5 s` (to be below activation threshold)  
5. **Verify** that `TTC_Eff = 0.5 s`  
6. **Verify** that `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²` throughout the 100 ms observation window  
7. **Set** `TTC_Raw = 1.6 s` (above `AEB_TTCActivate_C` but within valid range)  
8. **Verify** that `TTC_Eff = 1.6 s`  
9. **Verify** that `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²` throughout the 100 ms observation window  
10. **Set** `TTC_Raw = 1.4 s` (below `AEB_TTCActivate_C`)  
11. **Verify** that `TTC_Eff = 1.4 s`  
12. **Verify** that `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²` throughout the 100 ms observation window  
13. **Set** `TTC_Raw = 2.1 s` (above `AEB_TTCRelease_C`)  
14. **Verify** that `TTC_Eff = 2.1 s`  
15. **Verify** that `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²` throughout the 100 ms observation window  

### Acceptance Criteria  
- When `TTC_Eff > AEB_TTCActivate_C` (e.g., 3.0 s, 1.6 s), the system remains inactive:  
  - `AEB_Active = 0`  
  - `AEB_DecelReq = 0.0 m/s²`  
- When `TTC_Eff ≤ AEB_TTCActivate_C` (e.g., 1.4 s), the system does **not** activate; it remains inactive:  
  - `AEB_Active = 0`  
  - `AEB_DecelReq = 0.0 m/s²`  
- All state transitions are observed within 100 ms, with no change in `AEB_Active` or `AEB_DecelReq` when eligibility conditions are false or TTC exceeds activation threshold.  
- The controller does **not** activate or request deceleration under any condition where `TTC_Eff > AEB_TTCActivate_C`, regardless of vehicle speed or target detection status.  
- All validations occur within 20 ms of the input change, and the output remains zero throughout the 100 ms observation period.  
- No direct writing of `AEB_Active` or `AEB_DecelReq` is performed; all changes are derived from input and calibration logic.

### Reference draft

#### Preconditions

1. Set the simulated controller execution period to 10 ms and synchronized post-execution logging to 10 ms; log all applied changes and relevant measurements.
2. Set `AEB_Enable_C = 0`; set `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`, `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, and `AEB_DecelCmd_C = -3.0 m/s²`.
3. Set `VehSpd_Raw = 50.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 3.0 s`, and `TTCValid_Raw = 1` through the simulated input source; set all four bypass enables to `0`.
4. Set `VehSpd_BypVal = 50.0 km/h`, `TargetDetected_BypVal = 1`, `TTC_BypVal = 3.0 s`, and `TTCValid_BypVal = 0`; then set `VehSpd_BypEn = 1`, `TargetDetected_BypEn = 1`, `TTC_BypEn = 1`, and `TTCValid_BypEn = 1`.
5. Verify within 20 ms that `VehSpd_Eff = 50.0 km/h`, `TargetDetected_Eff = 1`, `TTC_Eff = 3.0 s`, and `TTCValid_Eff = 0`; verify `AEB_Active = 0` after the disabled setup has been applied for 20 ms.
6. Set `AEB_Enable_C = 1` and hold for 100 ms; verify `AEB_Active = 0` throughout this window because TTC is 3.0 s.

#### Test Procedure/Test Steps

1. Set `TTC_BypVal = 1.4 s`; verify `TTC_Eff = 1.4 s` within 20 ms; hold for 100 ms.
2. Verify `TTCValid_Eff = 0` persists and verify `AEB_Active = 0` at every sample throughout the window.

#### Acceptance Criteria

1. Verify AEB remains inactive for the full 100 ms with `TTCValid_Eff = 0`, despite TTC being below the activation threshold.

## AEB-TC-010 — Verify inhibition below the minimum and above the maximum operating speed in two independent runs.

Status: generated

### Generated output

### Preconditions  
- Controller initialized with `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²`.  
- All bypass enables set to `0`: `VehSpd_BypEn = 0`, `TargetDetected_BypEn = 0`, `TTC_BypEn = 0`, `TTCValid_BypEn = 0`.  
- Raw inputs set to:  
  - `VehSpd_Raw = 5.0 km/h`  
  - `TargetDetected_Raw = 1`  
  - `TTC_Raw = 3.0 s`  
  - `TTCValid_Raw = 1`  
- Calibration values at default:  
  - `AEB_Enable_C = 1`  
  - `AEB_MinSpd_C = 10.0 km/h`  
  - `AEB_MaxSpd_C = 80.0 km/h`  
  - `AEB_TTCActivate_C = 1.5 s`  
  - `AEB_TTCRelease_C = 2.0 s`  
  - `AEB_DecelCmd_C = -3.0 m/s²`  

---

### Test Procedure/Test Steps  
**Run 1: Verify inhibition below minimum operating speed**  
1. **Set**: `VehSpd_Raw = 5.0 km/h` (below `AEB_MinSpd_C = 10.0 km/h`)  
2. **Verify**: After 20 ms of execution, `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²`  
3. **Verify**: Throughout the 100 ms observation window, `AEB_Active` remains `0` and `AEB_DecelReq` remains `0.0 m/s²`  
4. **Verify**: No change in `AEB_Active` or `AEB_DecelReq` occurs despite `TTC_Eff = 3.0 s` and `TargetDetected_Eff = 1`  

**Run 2: Verify inhibition above maximum operating speed**  
1. **Set**: `VehSpd_Raw = 90.0 km/h` (above `AEB_MaxSpd_C = 80.0 km/h`)  
2. **Verify**: After 20 ms of execution, `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²`  
3. **Verify**: Throughout the 100 ms observation window, `AEB_Active` remains `0` and `AEB_DecelReq` remains `0.0 m/s²`  
4. **Verify**: No change in `AEB_Active` or `AEB_DecelReq` occurs despite `TTC_Eff = 3.0 s` and `TargetDetected_Eff = 1`  

**Post-run reset**:  
5. **Set**: `AEB_Enable_C = 0`  
6. **Set**: All bypass enables to `0`  
7. **Set**: Raw inputs to initial values (reinitialize for next independent test)  

---

### Acceptance Criteria  
- In both runs, AEB remains **inactive** (`AEB_Active = 0`) and requests **no deceleration** (`AEB_DecelReq = 0.0 m/s²`) when vehicle speed is below `10.0 km/h` or above `80.0 km/h`.  
- The controller **does not activate** despite valid target detection (`TargetDetected_Eff = 1`), valid TTC (`TTC_Eff = 3.0 s`), and valid TTC validity (`TTCValid_Eff = 1`).  
- All output values remain unchanged throughout the 100 ms observation window, with no output update within 20 ms of input change.  
- The inhibition behavior is **independent of TTC value** and occurs solely due to speed eligibility conditions.  
- No bypass logic is enabled; all effective inputs follow raw inputs.  
- The test satisfies requirement **AEB-REQ-004**: "When inactive, AEB shall remain inactive whenever any eligibility condition is false or `TTC_Eff > AEB_TTCActivate_C`."  
  - In both runs, eligibility condition 2 (speed eligibility) is false, thus AEB remains inactive.

### Reference draft

#### Preconditions

1. Set the simulated controller execution period to 10 ms and synchronized post-execution logging to 10 ms; log all applied changes and relevant measurements.
2. Set `AEB_Enable_C = 0`; set `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`, `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, and `AEB_DecelCmd_C = -3.0 m/s²`.
3. Set `VehSpd_Raw = 50.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 3.0 s`, and `TTCValid_Raw = 1` through the simulated input source; set all four bypass enables to `0`.
4. Set `VehSpd_BypVal = 50.0 km/h`, `TargetDetected_BypVal = 1`, `TTC_BypVal = 3.0 s`, and `TTCValid_BypVal = 1`; then set `VehSpd_BypEn = 1`, `TargetDetected_BypEn = 1`, `TTC_BypEn = 1`, and `TTCValid_BypEn = 1`.
5. Verify within 20 ms that `VehSpd_Eff = 50.0 km/h`, `TargetDetected_Eff = 1`, `TTC_Eff = 3.0 s`, and `TTCValid_Eff = 1`; verify `AEB_Active = 0` after the disabled setup has been applied for 20 ms.
6. Set `AEB_Enable_C = 1` and hold for 100 ms; verify `AEB_Active = 0` throughout this window because TTC is 3.0 s.
7. Set up two independent runs with speed values 9.9 km/h and 80.1 km/h; repeat the full preconditions before each run.

#### Test Procedure/Test Steps

1. Set `VehSpd_BypVal` to the run’s speed; verify `VehSpd_Eff` equals that value within 20 ms while TTC remains 3.0 s.
2. Set `TTC_BypVal = 1.4 s`; verify `TTC_Eff = 1.4 s` within 20 ms; hold for 100 ms and verify `AEB_Active = 0` throughout.

#### Acceptance Criteria

1. Verify AEB remains inactive throughout each run: at 9.9 km/h and at 80.1 km/h, despite all other activation conditions being satisfied.

## AEB-TC-011 — Active-state retention in the hysteresis band

Status: generated

### Generated output

### Preconditions  
- Initial state: `AEB_Active = 0`, `AEB_DecelReq = 0.0 m/s²`  
- All eligibility conditions are false:  
  - `VehSpd_Eff = 5.0 km/h` (below `AEB_MinSpd_C = 10.0 km/h`)  
  - `TargetDetected_Eff = 0`  
  - `TTCValid_Eff = 0`  
- Calibration values:  
  - `AEB_Enable_C = 1`  
  - `AEB_MinSpd_C = 10.0 km/h`  
  - `AEB_MaxSpd_C = 80.0 km/h`  
  - `AEB_TTCActivate_C = 1.5 s`  
  - `AEB_TTCRelease_C = 2.0 s`  
  - `AEB_DecelCmd_C = -3.0 m/s²`  
- Bypass enables: all set to `0` (no bypass active)  
- Raw inputs:  
  - `VehSpd_Raw = 5.0 km/h`  
  - `TargetDetected_Raw = 0`  
  - `TTC_Raw = 3.0 s`  
  - `TTCValid_Raw = 0`  

### Test Procedure/Test Steps  
1. **Set** `AEB_Enable_C = 1` (feature enabled)  
2. **Set** `VehSpd_Eff` via bypass:  
   - Enable `VehSpd_BypEn = 1`  
   - Set `VehSpd_BypVal = 15.0 km/h`  
3. **Set** `TargetDetected_Eff` via bypass:  
   - Enable `TargetDetected_BypEn = 1`  
   - Set `TargetDetected_BypVal = 1`  
4. **Set** `TTC_Eff` via bypass:  
   - Enable `TTC_BypEn = 1`  
   - Set `TTC_BypVal = 1.8 s`  
5. **Set** `TTCValid_Eff` via bypass:  
   - Enable `TTCValid_BypEn = 1`  
   - Set `TTCValid_BypVal = 1`  
6. **Set** `VehSpd_Raw = 15.0 km/h` (maintains `VehSpd_Eff = 15.0 km/h`)  
7. **Set** `TargetDetected_Raw = 1` (maintains `TargetDetected_Eff = 1`)  
8. **Set** `TTC_Raw = 1.8 s` (maintains `TTC_Eff = 1.8 s`)  
9. **Set** `TTCValid_Raw = 1` (maintains `TTCValid_Eff = 1`)  
10. **Verify** that within 20 ms of step 10, `AEB_Active = 1` (active state established)  
11. **Verify** that `AEB_DecelReq = -3.0 m/s²` (matches `AEB_DecelCmd_C`)  
12. **Set** `TTC_Raw = 1.9 s` (TTC increases to 1.9 s, still < 2.0 s)  
13. **Verify** that `AEB_Active = 1` remains active throughout the 100 ms observation window  
14. **Verify** that `AEB_DecelReq = -3.0 m/s²` remains unchanged throughout the 100 ms window  
15. **Set** `TTC_Raw = 2.1 s` (TTC exceeds `AEB_TTCRelease_C`)  
16. **Verify** that within 20 ms of this change, `AEB_Active = 0` (deactivation due to release condition)  
17. **Verify** that `AEB_DecelReq = 0.0 m/s²` after deactivation  

### Acceptance Criteria  
- After eligibility conditions are satisfied (`VehSpd_Eff ≥ 10.0 km/h`, `TargetDetected_Eff = 1`, `TTCValid_Eff = 1`, and `TTC_Eff < 2.0 s`), `AEB_Active` must transition to `1` within 20 ms.  
- While in active state and all eligibility conditions remain satisfied, `AEB_Active` must remain `1` and `AEB_DecelReq` must remain `-3.0 m/s²` as long as `TTC_Eff < 2.0 s`.  
- When `TTC_Eff ≥ 2.0 s`, `AEB_Active` must transition to `0` within 20 ms and `AEB_DecelReq` must become `0.0 m/s²`.  
- All effective inputs are derived from bypassed raw inputs; no direct write to `AEB_Active` or `AEB_DecelReq`.  
- The active state is maintained continuously during the 100 ms observation window as long as `TTC_Eff < 2.0 s` and eligibility conditions are met.  
- No output changes occur outside of the 20 ms deadline from input or calibration changes.

### Reference draft

#### Preconditions

1. Set the simulated controller execution period to 10 ms and synchronized post-execution logging to 10 ms; log all applied changes and relevant measurements.
2. Set `AEB_Enable_C = 0`; set `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`, `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, and `AEB_DecelCmd_C = -3.0 m/s²`.
3. Set `VehSpd_Raw = 50.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 3.0 s`, and `TTCValid_Raw = 1` through the simulated input source; set all four bypass enables to `0`.
4. Set `VehSpd_BypVal = 50.0 km/h`, `TargetDetected_BypVal = 1`, `TTC_BypVal = 3.0 s`, and `TTCValid_BypVal = 1`; then set `VehSpd_BypEn = 1`, `TargetDetected_BypEn = 1`, `TTC_BypEn = 1`, and `TTCValid_BypEn = 1`.
5. Verify within 20 ms that `VehSpd_Eff = 50.0 km/h`, `TargetDetected_Eff = 1`, `TTC_Eff = 3.0 s`, and `TTCValid_Eff = 1`; verify `AEB_Active = 0` after the disabled setup has been applied for 20 ms.
6. Set `AEB_Enable_C = 1` and hold for 100 ms; verify `AEB_Active = 0` throughout this window because TTC is 3.0 s.
7. Set `TTC_BypVal = 1.4 s`; verify `TTC_Eff = 1.4 s` and `AEB_Active = 1` within 20 ms of the applied change; hold for 100 ms and verify the active state persists.

#### Test Procedure/Test Steps

1. Set `TTC_BypVal = 1.6 s`; verify `TTC_Eff = 1.6 s` within 20 ms and verify `AEB_Active = 1` throughout 100 ms.
2. Set `TTC_BypVal = 1.9 s`; verify `TTC_Eff = 1.9 s` within 20 ms and verify `AEB_Active = 1` throughout another 100 ms.

#### Acceptance Criteria

1. Verify an already active controller remains active at 1.6 s and 1.9 s while eligible; exceeding the activation threshold alone shall not release AEB.

## AEB-TC-012 — Release at the TTC threshold

Status: generated

### Generated output

### Preconditions  
- Controller initialization: `AEB_Active = 0`, `AEB_DecelReq = 0.0 m/s²`  
- All bypass enables set to `0`: `VehSpd_BypEn = 0`, `TargetDetected_BypEn = 0`, `TTC_BypEn = 0`, `TTCValid_BypEn = 0`  
- Raw inputs set:  
  - `VehSpd_Raw = 20.0 km/h`  
  - `TargetDetected_Raw = 1`  
  - `TTC_Raw = 2.1 s`  
  - `TTCValid_Raw = 1`  
- Calibration values:  
  - `AEB_Enable_C = 1`  
  - `AEB_MinSpd_C = 10.0 km/h`  
  - `AEB_MaxSpd_C = 80.0 km/h`  
  - `AEB_TTCActivate_C = 1.5 s`  
  - `AEB_TTCRelease_C = 2.0 s`  
  - `AEB_DecelCmd_C = -3.0 m/s²`  

### Test Procedure/Test Steps  
1. **Set** `TTC_Raw = 2.1 s` (via simulated input source) and verify `TTC_Eff = 2.1 s` (with `TTCValid_Eff = 1`)  
2. **Set** `TTC_BypEn = 1` and **Set** `TTC_BypVal = 2.1 s` to ensure bypass is active; verify `TTC_Eff = 2.1 s`  
3. **Verify** that `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²` at t = 0 ms (initial state)  
4. **Set** `TTC_Raw = 1.9 s` at t = 0 ms (change applied)  
5. **Verify** that `TTC_Eff` updates to `1.9 s` within 20 ms of the change (within 20 ms deadline)  
6. **Verify** that `AEB_Active` remains `0` and `AEB_DecelReq` remains `0.0 m/s²` throughout the 100 ms observation window  
7. **Set** `TTC_Raw = 1.4 s` at t = 0 ms  
8. **Verify** that `TTC_Eff = 1.4 s` within 20 ms of change  
9. **Verify** that `AEB_Active` remains `0` and `AEB_DecelReq` remains `0.0 m/s²` throughout the 100 ms window  
10. **Set** `TTC_Raw = 2.0 s` at t = 0 ms  
11. **Verify** that `TTC_Eff = 2.0 s` within 20 ms of change  
12. **Verify** that `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²` throughout the 100 ms window  
13. **Set** `TTC_Raw = 1.9 s` at t = 0 ms  
14. **Verify** that `TTC_Eff = 1.9 s` within 20 ms of change  
15. **Verify** that `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²` throughout the 100 ms window  

### Acceptance Criteria  
- When `TTC_Eff ≥ AEB_TTCRelease_C` (i.e., `TTC_Eff ≥ 2.0 s`), the AEB controller must **deactivate** within 20 ms of the condition being met.  
- The `AEB_Active` output must transition from `1` to `0` (or remain `0`) when `TTC_Eff ≥ 2.0 s`, and this transition must occur within 20 ms of the input change.  
- The `AEB_DecelReq` output must remain at `0.0 m/s²` when the system is inactive, regardless of the `TTC_Eff` value.  
- No change to `AEB_Active` or `AEB_DecelReq` occurs when `TTC_Eff < 2.0 s` and the system is inactive.  
- All effective input updates (including `TTC_Eff`) must be reflected within 20 ms of the raw input change.  
- The controller must not transition to active state due to `TTC_Eff ≥ 2.0 s` when eligibility conditions are not satisfied.  
- All observations (inputs, outputs) are logged synchronously every 10 ms, and the 20 ms response deadline is met for all effective input changes.

### Reference draft

#### Preconditions

1. Set the simulated controller execution period to 10 ms and synchronized post-execution logging to 10 ms; log all applied changes and relevant measurements.
2. Set `AEB_Enable_C = 0`; set `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`, `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, and `AEB_DecelCmd_C = -3.0 m/s²`.
3. Set `VehSpd_Raw = 50.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 3.0 s`, and `TTCValid_Raw = 1` through the simulated input source; set all four bypass enables to `0`.
4. Set `VehSpd_BypVal = 50.0 km/h`, `TargetDetected_BypVal = 1`, `TTC_BypVal = 3.0 s`, and `TTCValid_BypVal = 1`; then set `VehSpd_BypEn = 1`, `TargetDetected_BypEn = 1`, `TTC_BypEn = 1`, and `TTCValid_BypEn = 1`.
5. Verify within 20 ms that `VehSpd_Eff = 50.0 km/h`, `TargetDetected_Eff = 1`, `TTC_Eff = 3.0 s`, and `TTCValid_Eff = 1`; verify `AEB_Active = 0` after the disabled setup has been applied for 20 ms.
6. Set `AEB_Enable_C = 1` and hold for 100 ms; verify `AEB_Active = 0` throughout this window because TTC is 3.0 s.
7. Set `TTC_BypVal = 1.4 s`; verify `TTC_Eff = 1.4 s` and `AEB_Active = 1` within 20 ms of the applied change; hold for 100 ms and verify the active state persists.

#### Test Procedure/Test Steps

1. Set `TTC_BypVal = 1.9 s`; verify `TTC_Eff = 1.9 s` within 20 ms and verify `AEB_Active = 1` throughout 100 ms.
2. Set `TTC_BypVal = 2.0 s`; verify `TTC_Eff = 2.0 s` and `AEB_Active = 0` within 20 ms of the applied change; hold for 100 ms.

#### Acceptance Criteria

1. Verify AEB remains active below release at 1.9 s.
2. Verify AEB deactivates at exactly 2.0 s within 20 ms and remains inactive through 100 ms.

## AEB-TC-013 — Release on target loss

Status: generated

### Generated output

### Preconditions  
- Controller initialized: `AEB_Active = 0`, `AEB_DecelReq = 0.0 m/s²`  
- `AEB_Enable_C = 1`  
- `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`  
- `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, `AEB_DecelCmd_C = -3.0 m/s²`  
- Raw inputs:  
  - `VehSpd_Raw = 30.0 km/h` → `VehSpd_Eff = 30.0 km/h` (bypass disabled)  
  - `TargetDetected_Raw = 1` → `TargetDetected_Eff = 1` (bypass disabled)  
  - `TTC_Raw = 1.8 s` → `TTC_Eff = 1.8 s` (bypass disabled)  
  - `TTCValid_Raw = 1` → `TTCValid_Eff = 1` (bypass disabled)  
- All bypass enables: `VehSpd_BypEn = 0`, `TargetDetected_BypEn = 0`, `TTC_BypEn = 0`, `TTCValid_BypEn = 0`  
- System is in **inactive** state due to eligibility conditions being satisfied but TTC > AEB_TTCActivate_C  

### Test Procedure/Test Steps  
1. **Set** `TTC_Raw = 1.8 s` (TTC_Eff = 1.8 s) and hold for 100 ms.  
2. **Set** `TTC_Raw = 0.5 s` (TTC_Eff = 0.5 s) at timestamp t=0 ms.  
3. **Verify** that within 20 ms of the change, `AEB_Active` transitions from 0 to 1 (active).  
4. **Verify** that `AEB_DecelReq` becomes `-3.0 m/s²` within 20 ms of the change.  
5. **Set** `TTC_Raw = 2.5 s` (TTC_Eff = 2.5 s) at timestamp t=20 ms.  
6. **Verify** that within 20 ms of the change, `AEB_Active` transitions from 1 to 0 (inactive).  
7. **Verify** that `AEB_DecelReq` returns to `0.0 m/s²` within 20 ms of the change.  
8. **Verify** that all eligibility conditions remain satisfied (VehSpd_Eff = 30.0 km/h, TargetDetected_Eff = 1, TTCValid_Eff = 1) throughout the 100 ms observation window.  

### Acceptance Criteria  
- `AEB_Active` deactivates within 20 ms when `TTC_Eff ≥ AEB_TTCRelease_C` (i.e., ≥ 2.0 s).  
- `AEB_DecelReq` transitions to `0.0 m/s²` within 20 ms of deactivation.  
- The deactivation occurs **only** when `TTC_Eff ≥ AEB_TTCRelease_C`, not due to any eligibility condition becoming false.  
- The transition is observed within 20 ms of the input change, and the output remains stable at 0.0 m/s² throughout the 100 ms observation window.  
- No bypass changes are applied to raw inputs except for the TTC input during the test.  
- All effective inputs and outputs are derived from raw inputs via bypass rules (all bypass enables remain 0).  
- The test verifies the release condition as defined in requirement **AEB-REQ-006**: deactivation within 20 ms when any eligibility condition becomes false or `TTC_Eff ≥ AEB_TTCRelease_C`. In this case, the condition is met solely by `TTC_Eff ≥ AEB_TTCRelease_C`.

### Reference draft

#### Preconditions

1. Set the simulated controller execution period to 10 ms and synchronized post-execution logging to 10 ms; log all applied changes and relevant measurements.
2. Set `AEB_Enable_C = 0`; set `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`, `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, and `AEB_DecelCmd_C = -3.0 m/s²`.
3. Set `VehSpd_Raw = 50.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 3.0 s`, and `TTCValid_Raw = 1` through the simulated input source; set all four bypass enables to `0`.
4. Set `VehSpd_BypVal = 50.0 km/h`, `TargetDetected_BypVal = 1`, `TTC_BypVal = 3.0 s`, and `TTCValid_BypVal = 1`; then set `VehSpd_BypEn = 1`, `TargetDetected_BypEn = 1`, `TTC_BypEn = 1`, and `TTCValid_BypEn = 1`.
5. Verify within 20 ms that `VehSpd_Eff = 50.0 km/h`, `TargetDetected_Eff = 1`, `TTC_Eff = 3.0 s`, and `TTCValid_Eff = 1`; verify `AEB_Active = 0` after the disabled setup has been applied for 20 ms.
6. Set `AEB_Enable_C = 1` and hold for 100 ms; verify `AEB_Active = 0` throughout this window because TTC is 3.0 s.
7. Set `TTC_BypVal = 1.4 s`; verify `TTC_Eff = 1.4 s` and `AEB_Active = 1` within 20 ms of the applied change; hold for 100 ms and verify the active state persists.

#### Test Procedure/Test Steps

1. Set `TargetDetected_BypVal = 0`; hold for 100 ms with TTC still 1.4 s.
2. Verify from the recorded trace that `TargetDetected_Eff = 0` and the first `AEB_Active = 0` sample both occur no later than 20 ms after the applied target change; verify the inactive state persists through the 100 ms window.

#### Acceptance Criteria

1. Verify AEB deactivates within 20 ms and remains inactive through 100 ms despite TTC remaining below the activation threshold.

## AEB-TC-014 — Release on feature disable

Status: generated

### Generated output

### Preconditions  
- Controller initialized: `AEB_Active = 0`, `AEB_DecelReq = 0.0 m/s²`  
- `AEB_Enable_C = 1`  
- `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`  
- `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`  
- `AEB_DecelCmd_C = -3.0 m/s²`  
- `VehSpd_Raw = 50.0 km/h` → `VehSpd_Eff = 50.0 km/h` (bypass disabled)  
- `TargetDetected_Raw = 1` → `TargetDetected_Eff = 1` (bypass disabled)  
- `TTC_Raw = 1.8 s` → `TTC_Eff = 1.8 s` (bypass disabled)  
- `TTCValid_Raw = 1` → `TTCValid_Eff = 1` (bypass disabled)  
- All bypass enables: `VehSpd_BypEn = 0`, `TargetDetected_BypEn = 0`, `TTC_BypEn = 0`, `TTCValid_BypEn = 0`  
- System is in **inactive** state due to eligibility conditions being satisfied but `TTC_Eff > AEB_TTCActivate_C`  

### Test Procedure/Test Steps  
1. **Set** `TTC_Raw = 1.8 s` (already set; verify no change)  
2. **Set** `TTCValid_Raw = 1` (already set; verify no change)  
3. **Set** `AEB_Enable_C = 1` (already set; verify no change)  
4. **Set** `VehSpd_Raw = 50.0 km/h` (already set; verify no change)  
5. **Set** `TargetDetected_Raw = 1` (already set; verify no change)  
6. **Set** `TTC_Eff` to `2.0 s` via `TTC_BypEn = 1` and `TTC_BypVal = 2.0 s`  
7. **Verify** that `TTC_Eff = 2.0 s` within 10 ms of the bypass enable application  
8. **Verify** that `AEB_Active` remains `0` (inactive) within 20 ms of the bypass change  
9. **Verify** that `AEB_DecelReq = 0.0 m/s²` throughout the 100 ms observation window  
10. **Set** `TTC_Eff` to `1.9 s` via `TTC_BypEn = 1` and `TTC_BypVal = 1.9 s`  
11. **Verify** that `TTC_Eff = 1.9 s` within 10 ms of the bypass change  
12. **Verify** that `AEB_Active` remains `0` (inactive) within 20 ms of the bypass change  
13. **Verify** that `AEB_DecelReq = 0.0 m/s²` throughout the 100 ms observation window  
14. **Set** `TTC_Eff` to `1.5 s` via `TTC_BypEn = 1` and `TTC_BypVal = 1.5 s`  
15. **Verify** that `TTC_Eff = 1.5 s` within 10 ms of the bypass change  
16. **Verify** that `AEB_Active` remains `0` (inactive) within 20 ms of the bypass change  
17. **Verify** that `AEB_DecelReq = 0.0 m/s²` throughout the 100 ms observation window  

### Acceptance Criteria  
- When `TTC_Eff ≥ AEB_TTCRelease_C` (i.e., `TTC_Eff ≥ 2.0 s`), the AEB controller must **deactivate** within **20 ms** of the condition being met.  
- The `AEB_Active` state must transition from `1` to `0` (inactive) when `TTC_Eff ≥ 2.0 s`, and this transition must occur within 20 ms of the input or bypass change.  
- The `AEB_DecelReq` output must remain at `0.0 m/s²` during the entire 100 ms observation window when the system is inactive.  
- No direct modification of `AEB_Active` or `AEB_DecelReq` is allowed; the state transition must be governed by eligibility and TTC logic.  
- All effective inputs are derived from raw inputs via bypass logic; bypass values are applied only through explicit bypass enable and value setting.  
- The deactivation response (release) occurs only when `TTC_Eff ≥ AEB_TTCRelease_C`, regardless of other eligibility conditions.  
- The controller must not activate during this test, as activation is only permitted when `TTC_Eff ≤ AEB_TTCActivate_C` (1.5 s), which is not satisfied.  
- All measurements (effective inputs, outputs) are verified within 20 ms of the applied change and throughout the 100 ms observation window.

### Reference draft

#### Preconditions

1. Set the simulated controller execution period to 10 ms and synchronized post-execution logging to 10 ms; log all applied changes and relevant measurements.
2. Set `AEB_Enable_C = 0`; set `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`, `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, and `AEB_DecelCmd_C = -3.0 m/s²`.
3. Set `VehSpd_Raw = 50.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 3.0 s`, and `TTCValid_Raw = 1` through the simulated input source; set all four bypass enables to `0`.
4. Set `VehSpd_BypVal = 50.0 km/h`, `TargetDetected_BypVal = 1`, `TTC_BypVal = 3.0 s`, and `TTCValid_BypVal = 1`; then set `VehSpd_BypEn = 1`, `TargetDetected_BypEn = 1`, `TTC_BypEn = 1`, and `TTCValid_BypEn = 1`.
5. Verify within 20 ms that `VehSpd_Eff = 50.0 km/h`, `TargetDetected_Eff = 1`, `TTC_Eff = 3.0 s`, and `TTCValid_Eff = 1`; verify `AEB_Active = 0` after the disabled setup has been applied for 20 ms.
6. Set `AEB_Enable_C = 1` and hold for 100 ms; verify `AEB_Active = 0` throughout this window because TTC is 3.0 s.
7. Set `TTC_BypVal = 1.4 s`; verify `TTC_Eff = 1.4 s` and `AEB_Active = 1` within 20 ms of the applied change; hold for 100 ms and verify the active state persists.

#### Test Procedure/Test Steps

1. Set `AEB_Enable_C = 0`; hold for 100 ms with TTC still 1.4 s.
2. Verify from the recorded trace that the first `AEB_Active = 0` sample occurs no later than 20 ms after the applied enable-calibration change; verify the inactive state persists through the 100 ms window.

#### Acceptance Criteria

1. Verify AEB deactivates within 20 ms and remains inactive through 100 ms despite TTC remaining below the activation threshold.

## AEB-TC-015 — Verify deceleration request in inactive and active states, same-cycle state/output updates, and an active-state command change from -3.0 to -2.0 m/s².

Status: generated

### Generated output

### Preconditions  
- Controller initialization: `AEB_Active = 0`, `AEB_DecelReq = 0.0 m/s²`  
- All bypass enables: `VehSpd_BypEn = 0`, `TargetDetected_BypEn = 0`, `TTC_BypEn = 0`, `TTCValid_BypEn = 0`  
- Raw inputs:  
  - `VehSpd_Raw = 15.0 km/h`  
  - `TargetDetected_Raw = 0`  
  - `TTC_Raw = 3.0 s`  
  - `TTCValid_Raw = 1`  
- Calibrations:  
  - `AEB_Enable_C = 1`  
  - `AEB_MinSpd_C = 10.0 km/h`  
  - `AEB_MaxSpd_C = 80.0 km/h`  
  - `AEB_TTCActivate_C = 1.5 s`  
  - `AEB_TTCRelease_C = 2.0 s`  
  - `AEB_DecelCmd_C = -3.0 m/s²`  

### Test Procedure/Test Steps  
1. **Set** `TargetDetected_Raw = 1` (to enable target detection)  
2. **Set** `TTC_Raw = 1.4 s` (within activation threshold)  
3. **Set** `TTCValid_Raw = 1` (valid TTC)  
4. **Set** `VehSpd_Raw = 20.0 km/h` (within speed eligibility range)  
5. **Verify** that within 20 ms of step 1, `AEB_Active` transitions to `1` and `AEB_DecelReq` becomes `-3.0 m/s²`  
6. **Verify** that `AEB_DecelReq` updates to `-3.0 m/s²` simultaneously with `AEB_Active` and remains at `-3.0 m/s²` for the next 100 ms  
7. **Set** `TTC_Raw = 2.1 s` (above release threshold)  
8. **Verify** that within 20 ms of step 7, `AEB_Active` transitions to `0` and `AEB_DecelReq` returns to `0.0 m/s²`  
9. **Verify** that `AEB_DecelReq` remains at `0.0 m/s²` throughout the next 100 ms  
10. **Set** `AEB_Enable_C = 0` (disable feature)  
11. **Set** all bypass enables to `0`  
12. **Set** `TargetDetected_Raw = 0` (no target)  
13. **Verify** that `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²` at initialization and throughout the test  

### Acceptance Criteria  
- In inactive state (`AEB_Active = 0`), `AEB_DecelReq` must equal `0.0 m/s²`  
- When `AEB_Active = 1`, `AEB_DecelReq` must equal `AEB_DecelCmd_C` (i.e., `-3.0 m/s²`)  
- Both `AEB_Active` and `AEB_DecelReq` must update together within 20 ms of any input or calibration change that affects eligibility or command value  
- During active state, `AEB_DecelReq` must remain at `-3.0 m/s²` until the state transitions to inactive due to `TTC_Eff ≥ AEB_TTCRelease_C`  
- Upon transition from active to inactive (due to `TTC_Eff > AEB_TTCRelease_C`), `AEB_DecelReq` must reset to `0.0 m/s²` within 20 ms  
- The deceleration request value must not change during inactive state, regardless of raw input changes  
- All validations must occur within 20 ms of input or calibration change, and the output values must be stable throughout the 100 ms observation window after the transition

### Reference draft

#### Preconditions

1. Set the simulated controller execution period to 10 ms and synchronized post-execution logging to 10 ms; log all applied changes and relevant measurements.
2. Set `AEB_Enable_C = 0`; set `AEB_MinSpd_C = 10.0 km/h`, `AEB_MaxSpd_C = 80.0 km/h`, `AEB_TTCActivate_C = 1.5 s`, `AEB_TTCRelease_C = 2.0 s`, and `AEB_DecelCmd_C = -3.0 m/s²`.
3. Set `VehSpd_Raw = 50.0 km/h`, `TargetDetected_Raw = 1`, `TTC_Raw = 3.0 s`, and `TTCValid_Raw = 1` through the simulated input source; set all four bypass enables to `0`.
4. Set `VehSpd_BypVal = 50.0 km/h`, `TargetDetected_BypVal = 1`, `TTC_BypVal = 3.0 s`, and `TTCValid_BypVal = 1`; then set `VehSpd_BypEn = 1`, `TargetDetected_BypEn = 1`, `TTC_BypEn = 1`, and `TTCValid_BypEn = 1`.
5. Verify within 20 ms that `VehSpd_Eff = 50.0 km/h`, `TargetDetected_Eff = 1`, `TTC_Eff = 3.0 s`, and `TTCValid_Eff = 1`; verify `AEB_Active = 0` after the disabled setup has been applied for 20 ms.
6. Set `AEB_Enable_C = 1` and hold for 100 ms; verify `AEB_Active = 0` throughout this window because TTC is 3.0 s.

#### Test Procedure/Test Steps

1. Verify `AEB_Active = 0` and `AEB_DecelReq = 0.0 m/s²` at every logged sample for 100 ms.
2. Set `TTC_BypVal = 1.4 s`; verify activation within 20 ms and verify the same post-execution sample first reporting `AEB_Active = 1` reports `AEB_DecelReq = -3.0 m/s²`; hold for 100 ms.
3. Set `AEB_DecelCmd_C = -2.0 m/s²`; verify `AEB_DecelReq = -2.0 m/s²` on the first controller execution that reads the applied calibration (within 20 ms). Verify `AEB_Active = 1` throughout 100 ms.
4. Set `TTC_BypVal = 2.0 s`; verify release within 20 ms and verify the same post-execution sample first reporting `AEB_Active = 0` reports `AEB_DecelReq = 0.0 m/s²`; hold for 100 ms.

#### Acceptance Criteria

1. Verify inactive state always corresponds to 0.0 m/s² in the logged windows.
2. Verify active state corresponds to the currently applied deceleration calibration: -3.0 m/s² initially and -2.0 m/s² after the calibration update is read.
3. Verify no logged controller cycle has mismatched active status and deceleration request. This validates cycle-level synchronization only, not sub-cycle write ordering.